module.exports = function(grunt) {

  // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    concat: {
      css: {
        src: ['vendors/bootstrap/dist/css/bootstrap.css', 'vendors/jasny-bootstrap/dist/css/jasny-bootstrap.css'],
        dest: 'vendors/vendors.css',
      },
      js: {
        src: ['vendors/bootstrap/dist/js/bootstrap.js', 'vendors/jasny-bootstrap/dist/js/jasny-bootstrap.js'],
        dest: 'vendors/vendors.js',
      }
    },
    sass: {
      options: {
        style: 'expanded'
      },
      build: {
        expand: true,
        cwd: 'css',
        src: ['styles.scss'],
        dest: 'css/',
        ext: '.css'
      }
    },
    cssmin: {
      options: {
        root: './'
      },
      build: {
        src: 'css/styles.css',
        dest: 'css/styles.min.css'
      }
    },
    watch: {
      scss: {
        options: {
          livereload: true
        },
        files: ['css/styles.scss'],
        tasks: ['sass', 'cssmin']
      }
    }
  });

  // Load the plugin that provides the "uglify" task.
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.loadNpmTasks('grunt-contrib-sass');
  grunt.loadNpmTasks('grunt-contrib-concat');
  grunt.loadNpmTasks('grunt-contrib-watch');

  // Default task(s).
  grunt.registerTask('default', ['concat', 'sass', 'cssmin']);
  grunt.registerTask('dev', ['concat', 'sass', 'cssmin', 'watch']);
};